package com.dxc.ams2.entity;


public class Manager {
	String MGNO;
	String FirstName;
	String LastName;
	String LoginName;
	String LoginPwd;
	String EmailID;
	String PhoneNo;
	
	public Manager(String mGNO, String firstName, String lastName, String loginName, String loginPwd, String emailID,
			String phoneNo) {
		super();
		MGNO = mGNO;
		FirstName = firstName;
		LastName = lastName;
		LoginName = loginName;
		LoginPwd = loginPwd;
		EmailID = emailID;
		PhoneNo = phoneNo;
	}
	
	@Override
	public String toString() {
		return "Manager [MGNO=" + MGNO + ", FirstName=" + FirstName + ", LastName=" + LastName + ", LoginName="
				+ LoginName + ", LoginPwd=" + LoginPwd + ", EmailID=" + EmailID + ", PhoneNo=" + PhoneNo + "]";
	}
	
	public String getMGNO() {
		return MGNO;
	}

	public void setMGNO(String mGNO) {
		MGNO = mGNO;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getLoginName() {
		return LoginName;
	}

	public void setLoginName(String loginName) {
		LoginName = loginName;
	}

	public String getLoginPwd() {
		return LoginPwd;
	}

	public void setLoginPwd(String loginPwd) {
		LoginPwd = loginPwd;
	}

	public String getEmailID() {
		return EmailID;
	}

	public void setEmailID(String emailID) {
		EmailID = emailID;
	}

	public String getPhoneNo() {
		return PhoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	

}
