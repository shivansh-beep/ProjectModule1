package com.dxc.ams2.entity;

public class Appointment {
	private String APID;
	private String AGNO;
	private String APDate;
	private  String Time;
	private String CSName;
	public Appointment(String aPID, String aGNO, String aPDate, String time, String cSName) {
		super();
		APID = aPID;
		AGNO = aGNO;
		APDate = aPDate;
		Time = time;
		CSName = cSName;
	}

	@Override
	public String toString() {
		return "Appointment [APID=" + APID + ", AGNO=" + AGNO + ", APDate=" + APDate + ", Time=" + Time + ", CSName="
				+ CSName + "]";
	}
	
	public String getAPID() {
		return APID;
	}
	public void setAPID(String aPID) {
		APID = aPID;
	}
	public String getAGNO() {
		return AGNO;
	}
	public void setAGNO(String aGNO) {
		AGNO = aGNO;
	}
	public String getAPDate() {
		return APDate;
	}
	public void setAPDate(String aPDate) {
		APDate = aPDate;
	}
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	public String getCSName() {
		return CSName;
	}
	public void setCSName(String cSName) {
		CSName = cSName;
	}
	
}
