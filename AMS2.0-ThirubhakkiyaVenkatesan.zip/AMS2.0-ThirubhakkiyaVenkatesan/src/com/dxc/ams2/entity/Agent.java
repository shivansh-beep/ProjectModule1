package com.dxc.ams2.entity;

public class Agent {
	
	public Agent(String aGNO, String firstName, String lastName, String loginName, String loginPwd, String eMailId,
			String phoneNo, int target, String targetDate, String targetSetDate, int policiesSold) {
		super();
		AGNO = aGNO;
		FirstName = firstName;
		LastName = lastName;
		LoginName = loginName;
		LoginPwd = loginPwd;
		EMailId = eMailId;
		PhoneNo = phoneNo;
		Target = target;
		TargetDate = targetDate;
		TargetSetDate = targetSetDate;
		PoliciesSold = policiesSold;
	}
	
	public String getAGNO() {
		return AGNO;
	}
	public void setAGNO(String aGNO) {
		AGNO = aGNO;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getLoginName() {
		return LoginName;
	}
	public void setLoginName(String loginName) {
		LoginName = loginName;
	}
	public String getLoginPwd() {
		return LoginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		LoginPwd = loginPwd;
	}
	public String getEMailId() {
		return EMailId;
	}
	public void setEMailId(String eMailId) {
		EMailId = eMailId;
	}
	public String getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	public int getTarget() {
		return Target;
	}
	public void setTarget(int target) {
		Target = target;
	}
	public String getTargetDate() {
		return TargetDate;
	}
	public void setTargetDate(String targetDate) {
		TargetDate = targetDate;
	}
	public String getTargetSetDate() {
		return TargetSetDate;
	}
	public void setTargetSetDate(String targetSetDate) {
		TargetSetDate = targetSetDate;
	}
	public int getPoliciesSold() {
		return PoliciesSold;
	}
	public void setPoliciesSold(int policiesSold) {
		PoliciesSold = policiesSold;
	}
	private String AGNO;
	@Override
	public String toString() {
		return "Agent [AGNO=" + AGNO + ", FirstName=" + FirstName + ", LastName=" + LastName + ", LoginName="
				+ LoginName + ", LoginPwd=" + LoginPwd + ", EMailId=" + EMailId + ", PhoneNo=" + PhoneNo + ", Target="
				+ Target + ", TargetDate=" + TargetDate + ", TargetSetDate=" + TargetSetDate + ", PoliciesSold="
				+ PoliciesSold + "]";
	}
	private String FirstName;
	private String LastName;
	private String LoginName;
	private String LoginPwd;
	private String EMailId ;
	private String PhoneNo;
	private int Target;
	private String TargetDate;
	private String TargetSetDate;
	private int PoliciesSold;
	
	

}
