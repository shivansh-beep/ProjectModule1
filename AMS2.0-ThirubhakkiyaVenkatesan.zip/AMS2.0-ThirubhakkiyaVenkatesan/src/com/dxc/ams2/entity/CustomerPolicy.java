package com.dxc.ams2.entity;

public class CustomerPolicy {
	private String policyno;
	public CustomerPolicy(String policyno, String csno, String pdate, String years, String pamt, 
			String mode, String premium) {
		super();
		this.policyno = policyno;
		this.csno = csno;
		
		this.years = years;
		this.pamt = pamt;
		
		this.mode = mode;
		this.premium = premium;
	}
	private String csno;
	
	private String years;
	private String pamt;
	
	private String mode;
	private String premium;
    @Override
	public String toString() {
		return "Customer [policyno=" + policyno + ", csno=" + csno + ", pdate=" +", years=" + years + ", pamt="
				+ pamt + ", Email=" + ", mode=" + mode + ", premium=" + premium + "]";
	}
	
    public void Customer(String policyno, String csno, String pdate, String years, String pamt, String email, String mode,
			String premium) {
		
		this.policyno = policyno;
		this.csno = csno;
		
		this.years = years;
		this.pamt = pamt;
		
		this.mode = mode;
		this.premium = premium;
	}

	
	public String getPolicyno() {
		return policyno;
	}
	public void setPolicyno(String policyno) {
		this.policyno = policyno;
	}
	public String getCsno() {
		return csno;
	}
	public void setCsno(String csno) {
		this.csno = csno;
	}
	
	public String getYears() {
		return years;
	}
	public void setYears(String years) {
		this.years = years;
	}
	public String getPamt() {
		return pamt;
	}
	public void setPamt(String pamt) {
		this.pamt = pamt;
	}
	
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getPremium() {
		return premium;
	}
	public void setPremium(String premium) {
		this.premium = premium;
	}
	


}
