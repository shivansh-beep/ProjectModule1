package com.dxc.ams2.entity;

public class Customer {
	private String  Csno;

	public String getCsno() {
		return Csno;
	}



	public void setCsno(String csno) {
		Csno = csno;
	}



	public String getFirstName() {
		return FirstName;
	}



	public void setFirstName(String firstName) {
		FirstName = firstName;
	}



	public String getLastName() {
		return LastName;
	}



	public void setLastName(String lastName) {
		LastName = lastName;
	}



	public String getLoginName() {
		return LoginName;
	}



	public void setLoginName(String loginName) {
		LoginName = loginName;
	}



	public String getLoginPwd() {
		return LoginPwd;
	}



	public void setLoginPwd(String loginPwd) {
		LoginPwd = loginPwd;
	}



	public String getEmail() {
		return Email;
	}



	public void setEmail(String email) {
		Email = email;
	}



	public String getPhone() {
		return Phone;
	}



	public void setPhone(String phone) {
		Phone = phone;
	}



	public String getAGNO() {
		return AGNO;
	}



	public void setAGNO(String aGNO) {
		AGNO = aGNO;
	}



	private String 	FirstName;
	private String	LastName;
	private String    LoginName;
	private String LoginPwd;
	private String Email;
	private String Phone;
	private String AGNO;
		
	public Customer(String csno, String firstName, String lastName, String loginName, String loginPwd, String email,
			String phone, String aGNO) {
		super();
		Csno = csno;
		FirstName = firstName;
		LastName = lastName;
		LoginName = loginName;
		LoginPwd = loginPwd;
		Email = email;
		Phone = phone;
		AGNO = aGNO;
	}


	
	@Override
	public String toString() {
		return "Customer [Csno=" + Csno + ", FirstName=" + FirstName + ", LastName=" + LastName + ", LoginName="
				+ LoginName + ", LoginPwd=" + LoginPwd + ", Email=" + Email + ", Phone=" + Phone + ", AGNO=" + AGNO
				+ "]";
	}
	
}