package com.dxc.ams2.entity;

public class ZonalManger {
	int ZMGNO;
	public int getZMGNO() {
		return ZMGNO;
	}



	public void setZMGNO(int zMGNO) {
		ZMGNO = zMGNO;
	}



	public String getFirstName() {
		return FirstName;
	}



	public void setFirstName(String firstName) {
		FirstName = firstName;
	}



	public String getLastName() {
		return LastName;
	}



	public void setLastName(String lastName) {
		LastName = lastName;
	}



	public String getLoginName() {
		return LoginName;
	}



	public void setLoginName(String loginName) {
		LoginName = loginName;
	}



	public String getLoginPwd() {
		return LoginPwd;
	}



	public void setLoginPwd(String loginPwd) {
		LoginPwd = loginPwd;
	}



	String FirstName;
	String LastName;
	String LoginName;
	String LoginPwd;
	@Override
	public String toString() {
		return "ZonalManger [ZMGNO=" + ZMGNO + ", FirstName=" + FirstName + ", LastName=" + LastName + ", LoginName="
				+ LoginName + ", LoginPwd=" + LoginPwd + "]";
	}

	
	
	public ZonalManger(int zMGNO, String firstName, String lastName, String loginName, String loginPwd) {
		super();
		ZMGNO = zMGNO;
		FirstName = firstName;
		LastName = lastName;
		LoginName = loginName;
		LoginPwd = loginPwd;
	}

	

}
