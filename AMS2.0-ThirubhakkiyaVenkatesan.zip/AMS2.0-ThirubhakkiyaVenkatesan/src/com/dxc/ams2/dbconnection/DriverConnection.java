package com.dxc.ams2.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DriverConnection {
	Connection c=null;
	public DriverConnection(){
	
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				System.out.println("Driver loaded ");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			// TODO Auto-generated catch block
	}
		
public Connection getConnected(){
	
		
		try {
			c = DriverManager.getConnection("jdbc:mysql://localhost:3306/amspro","root","subithiru07");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return c;
}
}
	


