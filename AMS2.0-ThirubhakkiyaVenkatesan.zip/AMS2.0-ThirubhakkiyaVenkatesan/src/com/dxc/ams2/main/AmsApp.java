package com.dxc.ams2.main;

import java.sql.SQLException;

import com.dxc.ams2.entity.Agent;
import com.dxc.ams2.entity.Appointment;
import com.dxc.ams2.entity.Customer;
import com.dxc.ams2.entity.CustomerPolicy;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.ZonalManger;
import com.dxc.ams2.impl.AgentImpl;
import com.dxc.ams2.impl.CustomerImpl;
import com.dxc.ams2.impl.ManagerImpl;
import com.dxc.ams2.impl.ZonalManagerimpl;

public class AmsApp {

	public static void main(String[] args){
		// TODO Auto-generated method stub
		//Agent M = new Agent("AG0016","Manish  ","MAlhotra","jk","jkjk","khj@ya.com","2125454"
		//, 124, "Tue Apr 05 00:00:00 GMT+05:30 2005", "Wed Mar 09 13:00:13 GMT+05:30 2005", 0);
		//ManagerImpl z = new ManagerImpl();
	//	z.setTarget("AG0035","prabhu", "100", "Mon Aug 08 00:00:00 GM", " Wed Oct 18 18:22:51 GMT+05:30 2006");
		//Manager M = new Manager("MG004", "Deepak", "Soni","deepak" , "soni", "deepak@gmail.com", "767767868");
		//ZonalManagerimpl Z = new ZonalManagerimpl();
		//Z.replaceManager(M, "siva");
		//Appointment A = new Appointment("AP004", "AG0016 ", "Tue Apr 05 00:00:00 GMT+05:30 2005", "9:00-10:00", "lokesh");
		//AgentImpl A1= new AgentImpl();
		//Customer C = new Customer("CS002", "Mukesh", "Gupta", "Mukesh", "Mukesh", "Mukesh@gmail.com","98009998", "AG0035");
		//Customer C = new Customer("CS001", "ravi", "jagan", "jaggu", "gaggudada", "jagan@gmail.com", "45273273", "AG0016");
		
		AgentImpl A1= new AgentImpl();
		A1.policyDetails();
		//CustomerPolicy C1 = new CustomerPolicy("JSK091", "Cs002", "06-16-2006", "7", "100000", "Quarterly", "750");
		//CustomerImpl C = new CustomerImpl();
		//C.policyDetails("Cs002");
		//ManagerImpl M = new ManagerImpl();
		//M.policyDetails();
		
			
		
 
	}

}
