package com.dxc.ams2.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.dxc.ams2.crud.AgentCurd;
import com.dxc.ams2.dbconnection.DriverConnection;
import com.dxc.ams2.entity.Appointment;
import com.dxc.ams2.entity.Customer;


public class AgentImpl extends ManagerImpl implements AgentCurd{
	
	public  AgentImpl(){
		 DriverConnection db = new DriverConnection();
			c= db.getConnected();
			if(c== null)
				
			{
				System.out.println("connection faild");
			}
			else if(c!=null) {
				System.out.println("connection connected..");
		}
			

	 }
	
	public void agentList() {
		ManagerImpl M =new ManagerImpl();
		M.agentList();
		
	}

	@Override
	public void makenewAppointment(Appointment A) {
		// TODO Auto-generated method stub
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("insert into appointment values(?,?,?,?,?)");
			ps.setString(1, A.getAPID());
			ps.setString(2, A.getAGNO());
			ps.setString(3, A.getAPDate());
			ps.setString(4, A.getTime());
			ps.setString(5, A.getCSName());
			
			ps.executeUpdate();
			System.out.println("an appointment has added to "+A.getAGNO());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void deleteAppointment(String APID, String CSName) {
		// TODO Auto-generated method stub
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("delete from appointment where APID=? and CSName=?");
			ps.setString(1, APID);
			ps.setString(2, CSName);
			ps.executeUpdate();
			System.out.println("an appointment has deleted to "+CSName);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	@Override
	public void addNewcostomer(Customer C) {
		// TODO Auto-generated method stub
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("insert into Customer values(?,?,?,?,?,?,?,?)");
			ps.setString(1, C.getCsno());
			ps.setString(2, C.getFirstName());
			ps.setString(3, C.getLastName());
			ps.setString(4, C.getLoginName());
			ps.setString(5, C.getLoginPwd());
			ps.setString(6, C.getEmail());
			ps.setString(7, C.getPhone());
			ps.setString(8, C.getAGNO());
			
			ps.executeUpdate();
			System.out.println(" new Costumer has been added ");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		}
		
		
	

	@Override
	public void viewReport() {
		// TODO Auto-generated method stub
		try {
			Statement s= c.createStatement();
			ResultSet r = s.executeQuery("select APID,AGNO,APDate,Time,CSName from Appointment");
			while(r.next()) {
				System.out.println("APID "+r.getString(1)+" AGNO "+r.getString(2)+" APDate "+r.getString(3)+" Time "+r.getString(4)+" CSName "+r.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	}
	public void lagout() {
		System.out.println("Agent Logged out");
		
	}
	void PolicyDetail() {
	      policyDetails();
	}
	

}
