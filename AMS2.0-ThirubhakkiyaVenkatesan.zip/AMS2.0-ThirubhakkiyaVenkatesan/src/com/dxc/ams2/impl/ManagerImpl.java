package com.dxc.ams2.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.dxc.ams2.crud.Logout;
import com.dxc.ams2.crud.ManagerCurd;
import com.dxc.ams2.dbconnection.DriverConnection;
import com.dxc.ams2.entity.Agent;
import com.dxc.ams2.entity.Manager;

public class ManagerImpl extends ZonalManagerimpl implements ManagerCurd,Logout {
	public ManagerImpl(){
		DriverConnection db = new DriverConnection();
		c= db.getConnected();
		if(c== null)
			
		{
			System.out.println("connection faild");
		}
		else if(c!=null) {
			System.out.println("connection connected..");
	}
		
	}

	@Override
	public void managerList() {
		// TODO Auto-generated method stub
		ZonalManagerimpl z= new ZonalManagerimpl();
		z.managerList();
	}
	
	public void agentList() {
		ZonalManagerimpl z= new ZonalManagerimpl();
		z.agentList();
	}

	@Override
	public void addNewagent(Agent A) {
		// TODO Auto-generated method stub
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("insert into Agent values(?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, A.getAGNO());
			ps.setString(2, A.getFirstName());
			ps.setString(3, A.getLastName());
			ps.setString(4, A.getLoginName());
			ps.setString(5, A.getLoginPwd());
			ps.setString(6, A.getEMailId());
			ps.setString(7, A.getPhoneNo());
			ps.setInt(8, A.getTarget());
			ps.setString(9, A.getTargetDate());
			ps.setString(10, A.getTargetSetDate());
			ps.setInt(11, A.getPoliciesSold());
			ps.executeUpdate();
			System.out.println(" Agent added ");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void agentPerformance() {
		// TODO Auto-generated method stub
		try {
			Statement s= c.createStatement();
			ResultSet r = s.executeQuery("select AGNO,FirstName,LastName,Target,TargetDate,TargetSetDate,PoliciesSold from Agent");
			while(r.next()) {
				System.out.println("AGNO "+r.getString(1)+" FirstName "+r.getString(2)+" LastName "+r.getString(3)+" Target "+r.getInt(4)+" TargetDate "+r.getString(5)+" TargetSetDate "+r.getString(6)+" PoliciesSold "+r.getInt(7));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	void Logout() {
		System.out.println("Logged out");
	}


	@Override
	public void replaceNewagent(Agent A, String S) {
		
		// TODO Auto-generated method stub
		String s= S;
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("update agent set  AGNO=?,FirstName=?,LastName=?,LoginName=?,LoginPwd =?,EMailId=?,PhoneNo=?,Target=?,TargetDate=?,TargetSetDate=?,PoliciesSold=? where FirstName=? ");
			ps.setString(1, A.getAGNO());
			ps.setString(2, A.getFirstName());
			ps.setString(3, A.getLastName());
			ps.setString(4, A.getLoginName());
			ps.setString(5, A.getLoginPwd());
			ps.setString(6, A.getEMailId());
			ps.setString(7, A.getPhoneNo());
			ps.setInt(8, A.getTarget());
			ps.setString(9, A.getTargetDate());
			ps.setString(10, A.getTargetSetDate());
			ps.setInt(11, A.getPoliciesSold());
			ps.setString(12,s);
			ps.executeUpdate();
			System.out.println(" An agent  has been replaced");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void setTarget(String AGNO,String FirstName,String Target,String TargetDate,String TargetSetDate) {
		// TODO Auto-generated method stub
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("update agent set Target=?,TargetDate=?,TargetSetDate=? where FirstName=?  and AGNO=? ");
			ps.setString(1, Target);
			ps.setString(2, TargetDate);
			ps.setString(3, TargetSetDate);
			ps.setString(4, FirstName);
		
			ps.setString(5, AGNO);
			ps.executeUpdate();
			System.out.println(" New Target has been assigned to agent ");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void policyDetails() {
		// TODO Auto-generated method stub
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("select Policyno,csno,years,Pamt,mode,premium from Customerpolicy");
			
			ResultSet r =ps.executeQuery();
			while(r.next()) {
				
			System.out.println("Policyno "+r.getString(1)+"csno "+r.getString(2)+"years "+r.getString(3)+"Pamt"
			+r.getString(4)+"mode"+r.getString(5)+"premium "+r.getString(6));
			}
					
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
		
	
	
	

}
