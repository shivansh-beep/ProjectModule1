package com.dxc.ams2.impl;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.dxc.ams2.crud.CustomerCurd;
import com.dxc.ams2.dbconnection.DriverConnection;
import com.dxc.ams2.entity.CustomerPolicy;

public class CustomerImpl implements CustomerCurd {
	Connection c=null;
	
	public CustomerImpl() {
		 DriverConnection db = new DriverConnection();
			 c = db.getConnected();
			if(c== null)
				
			{
				System.out.println("connection faild");
			}
			else if(c!=null) {
				System.out.println("connection connected..");
		}
	}
	

	@Override
	public void customerInfo(String CSID) {
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("select Csno,FirstName,LastName,LoginName,LoginPwd,Email,Phone,Phone from Customer where csno= ? ");
			ps.setString(1, CSID);
			ResultSet r =ps.executeQuery();
			while(r.next()) {
			System.out.println("CSNO "+r.getString(1)+"FirstName "+r.getString(2)+"LastName "+r.getString(3)+"LoginName"+r.getString(4)+
					"LoginPwd "+r.getString(5)+"Email"+r.getString(6)+"Phone "+r.getString(7)+"Phone"+r.getString(8));
					
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
		
		
		
	}

	@Override
	public void changePassword(String CSNO, String PWD ) {
		// TODO Auto-generated method stub
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("update Customer set LoginPwd=? where CSNO=? ");
			ps.setString(1, PWD);
			ps.setString(2, CSNO);
			
			ps.executeUpdate();
			System.out.println("PassWord updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void policyDetails(String C) {
		// TODO Auto-generated method stub
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("select Policyno,csno,years,Pamt,mode,premium from Customerpolicy where csno=?");
			ps.setString(1, C);
			ResultSet r =ps.executeQuery();
			while(r.next()) {
				
			System.out.println("Policyno "+r.getString(1)+"csno "+r.getString(2)+"years "+r.getString(3)+"Pamt"
			+r.getString(4)+"mode"+r.getString(5)+"premium "+r.getString(6));
			}
					
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*PreparedStatement ps;
		try {
			ps = c.prepareStatement("insert into CustomerPolicy values(?,?,?,?,?,?)");
			ps.setString(1, C.getPolicyno());
			ps.setString(2, C.getCsno());
			ps.setString(3, C.getYears());
			ps.setString(4, C.getPamt());
			ps.setString(5, C.getMode());
			ps.setString(6, C.getPremium());
			
		
		
			
			ps.executeUpdate();
			System.out.println(" New Target has been assigned to agent ");
		} catch (SQLException e) {
			// TODO Auto-generated catch block update CustomerPolicy set policyno=?,csno=?,pdate=?,years=?,pamt=?,,mode=?,premium=?"
			e.printStackTrace();
		}*/
		
		
		
		
		
	}
	

}
