package com.dxc.ams2.impl;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.dxc.ams2.crud.Logout;
import com.dxc.ams2.crud.ZonalManagercurd;
import com.dxc.ams2.dbconnection.DriverConnection;
import com.dxc.ams2.entity.Agent;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.ZonalManger;
import com.mysql.cj.xdevapi.Result;

public class ZonalManagerimpl implements ZonalManagercurd,Logout{
Connection c= null;
public ZonalManagerimpl(){
	DriverConnection db = new DriverConnection();
	c= db.getConnected();
	if(c== null)
		
	{
		System.out.println("connection faild");
	}
	else if(c!=null) {
		System.out.println("connection connected..");
}
}
@Override
public void ZonalManagerList() {
	// TODO Auto-generated method stub
	try {
		Statement s= c.createStatement();
		ResultSet r = s.executeQuery("select ZMGNO,FirstName,LastName,LoginName,LoginPwd from ZonalManager");
		while(r.next()) {
			System.out.println("ZMGNO "+r.getInt(1)+" FirstName "+r.getString(2)+" LastName "+r.getString(3)+" LoginName "+r.getString(4)+" LoginPwd "+r.getString(5));
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	
	/*try {
		PreparedStatement ps = c.prepareStatement("insert into ZonalManager values(?,?,?,?,?)");
		ps.setInt(1, m.getZMGNO());
		ps.setString(2, m.getFirstName());
		ps.setString(3, m.getLastName());
		ps.setString(4, m.getLoginName());
		ps.setString(5, m.getLoginPwd());
		ps.executeUpdate();
		}
	
	
	catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
	
		
	
	
	
}
@Override
public void addManager(Manager m) {
	// TODO Auto-generated method stub
	PreparedStatement ps;
	try {
		ps = c.prepareStatement("insert into Manager values(?,?,?,?,?,?,?)");
		ps.setString(1, m.getMGNO());
		ps.setString(2, m.getFirstName());
		ps.setString(3, m.getLastName());
		ps.setString(4, m.getLoginName());
		ps.setString(5, m.getLoginPwd());
		ps.setString(6, m.getEmailID());
		ps.setString(7, m.getPhoneNo());
		ps.executeUpdate();
		System.out.println("new Manager added ");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}@Override

public void managerList() {
	// TODO Auto-generated method stub
	try {
		Statement s= c.createStatement();
		ResultSet r = s.executeQuery("select MGNO,FirstName,LastName,LoginName,LoginPwd,EmailID,PhoneNo from Manager");
		while(r.next()) {
			System.out.println("ZMGNO "+r.getString(1)+" FirstName "+r.getString(2)+" LastName "+r.getString(3)+" LoginName "+r.getString(4)+" "
					+ " EmailID "+r.getString(6)+ " PhoneNo"+r.getString(7));
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
}
@Override
public void replaceManager(Manager m, String s) {
	// TODO Auto-generated method stub
	PreparedStatement ps;
	String S=s;
	try {
		ps = c.prepareStatement("update Manager set MGNO= ?,FirstName= ?, LastName =?,LoginName=?,LoginPwd= ?, EmailID =?,PhoneNo=? where FirstName = ?");
		ps.setString(1, m.getMGNO());
		ps.setString(2, m.getFirstName());
		ps.setString(3, m.getLastName());
		ps.setString(4, m.getLoginName());
		ps.setString(5, m.getLoginPwd());
		ps.setString(6, m.getEmailID());
		ps.setString(7, m.getPhoneNo());
		ps.setString(8, S);
		ps.executeUpdate();
		System.out.println("Manager has been replaced ");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	
}
	


@Override
public void agentList() {
	// TODO Auto-generated method stub
	
	try {
		Statement s= c.createStatement();
		ResultSet r = s.executeQuery("select AGNO,FirstName,LastName,LoginName,LoginPwd,EmailId,phoneNo,Target,TargetDate,TargetSetDate,PoliciesSold from Agent");
		while(r.next()) {
			System.out.println("AGNO "+r.getString(1)+" FirstName "+r.getString(2)+" LastName "+r.getString(3)+" LoginName "+r.getString(4)+" "
					+ " EmailID "+r.getString(6)+ " PhoneNo"+r.getString(7)+" Target "+r.getInt(8)+" TargetDate "+r.getString(9)+" TargetSetDate "+r.getString(10)+" PoliciesSold "+r.getInt(11));
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
	
	
	
	/*PreparedStatement ps;
	try {
		ps = c.prepareStatement("insert into Agent values(?,?,?,?,?,?,?,?,?,?,?)");
		ps.setString(1, A.getAGNO());
		ps.setString(2, A.getFirstName());
		ps.setString(3, A.getLastName());
		ps.setString(4, A.getLoginName());
		ps.setString(5, A.getLoginPwd());
		ps.setString(6, A.getEMailId());
		ps.setString(7, A.getPhoneNo());
		ps.setInt(8, A.getTarget());
		ps.setString(9, A.getTargetDate());
		ps.setString(10, A.getTargetSetDate());
		ps.setInt(11, A.getPoliciesSold());
		ps.executeUpdate();
		System.out.println(" Agent added ");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
	
	
	
	

@Override
public void layout() {
	// TODO Auto-generated method stub
	System.out.println("Logged out sccessfully");
}
@Override
public void policyDetails() {
	// TODO Auto-generated method stub
	ManagerImpl M= new ManagerImpl();
	M.policyDetails();
	
}
}
