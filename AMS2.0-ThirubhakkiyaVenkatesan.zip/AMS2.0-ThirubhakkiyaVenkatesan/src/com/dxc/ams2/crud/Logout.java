package com.dxc.ams2.crud;

import com.dxc.ams2.entity.Manager;

public interface Logout {
	void layout();

	

	
	

}
