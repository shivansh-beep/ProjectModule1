package com.dxc.ams2.crud;
import com.dxc.ams2.entity.Agent;

public interface ManagerCurd {
	

	


	
	void managerList();
	void agentList();
	void addNewagent(Agent A);
	void agentPerformance();
	void replaceNewagent(Agent a,String S);	
void setTarget(String AGNO,String FirstName,String Target,String TargetDate,String TargetSetDate);
	void policyDetails();

	


}
