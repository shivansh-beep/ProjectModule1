package com.dxc.ams2.crud;

import java.sql.SQLException;

import com.dxc.ams2.dbconnection.DriverConnection;
import com.dxc.ams2.entity.Agent;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.ZonalManger;

 public interface ZonalManagercurd {
	
	  void ZonalManagerList();
	  void addManager(Manager m);
	void managerList();
 void replaceManager(Manager m ,String m1);
	void agentList();
	void policyDetails();

}
