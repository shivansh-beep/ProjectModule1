package com.dxc.ams2.crud;

import com.dxc.ams2.entity.CustomerPolicy;

public interface CustomerCurd {
	void customerInfo(String CSID);
	void changePassword(String CSNO, String PWD);
	void policyDetails(String C);
}
