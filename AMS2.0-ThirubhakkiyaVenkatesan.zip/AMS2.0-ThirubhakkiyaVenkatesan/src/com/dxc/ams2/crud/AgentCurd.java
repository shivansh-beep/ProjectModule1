package com.dxc.ams2.crud;

import com.dxc.ams2.entity.Appointment;
import com.dxc.ams2.entity.Customer;

public interface AgentCurd {
	public void agentList();
	public void makenewAppointment(Appointment A);
	public void deleteAppointment(String APID, String CSName);
	public void addNewcostomer(Customer C);
	public void viewReport();
	public void policyDetails();

}
