package com.dxc.am2.customer.impl;

import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.dxc.ams2.customer.crud.CustomerCrud;
import com.dxc.ams2.dbconnection.DBConnection;
import com.dxc.ams2.entity.CustomerDetails;
import com.dxc.ams2.entity.PolicyDetails;
public class CustomerImpl implements CustomerCrud {

	
public void viewCustomer(CustomerDetails cd) {
	// TODO Auto-generated method stub
	 
	DBConnection db=new DBConnection();

	Connection c=db.getConnected();

	if(c==null)
	{
		System.out.println("connection failed");
	}
	else if(c!=null)
	{
		System.out.println("Succesfully Connected to Database");
	}

	try {
		Statement st=c.createStatement();
		ResultSet res=st.executeQuery("select * from customerdetails");
		while(res.next())
		{
			System.out.println(res.getString("cno")+"    "+res.getString("fname")+"   "+res.getString("lname")+"   "+res.getString("login")+"  "+res.getString("pwd")+" "+res.getString("email")+"  "+res.getString("addr")+"  "+res.getLong("phnum")+" "+res.getString("agno"));
			
		}
	
      }catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}

@Override
public void changePassword(CustomerDetails cd) {
	// TODO Auto-generated method stub
	DBConnection db=new DBConnection();

	Connection c=db.getConnected();

	if(c==null)
	{
		System.out.println("connection failed");
	}
	else if(c!=null)
	{
		System.out.println("Succesfully Connected to Database");
	}

	try {
		PreparedStatement ps=c.prepareStatement("update customerdetails set pwd='fail' where cno='CS021' ");
		ps.executeUpdate();
	
	
}catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}
	@Override
	public void viewPolicyDetails(PolicyDetails  pd) {
		
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			Statement st=c.createStatement();
			ResultSet res=st.executeQuery("select * from policy1");
			while(res.next())
			{
				System.out.println(res.getString("pno")+"   "+res.getString("csno")+"   "+res.getString("pdate")+"   "+res.getInt("year")+"   "+res.getLong("pamt")+"   "+res.getString("mode")+"   "+res.getInt("premium"));
				
			}
		
	      }catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
		
	}

	

	

	

	




	


		
	

		
	

	


