package com.dxc.ams2.customer.crud;

import com.dxc.ams2.entity.CustomerDetails;
import com.dxc.ams2.entity.PolicyDetails;

public interface CustomerCrud {
	public void viewCustomer(CustomerDetails cd);
         public void changePassword(CustomerDetails cd);
	public void viewPolicyDetails(PolicyDetails pd);
}

