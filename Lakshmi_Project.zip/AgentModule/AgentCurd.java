package com.dxc.ams2.agent.crud;

import com.dxc.ams2.entity.Appt;
import com.dxc.ams2.entity.CustomerDetails;
import com.dxc.ams2.entity.PolicyDetails;

public interface AgentCurd {
        void addCustomerDetails(CustomerDetails cd);
	void addApp(Appt a);
	void NewAppointment(Appt a);
	void deleteAppoinment(Appt a);
	void viewPolicyDetails(PolicyDetails pd);
	void viewAppInfo(Appt a);
	void viewCustDetails(CustomerDetails cd);
}
