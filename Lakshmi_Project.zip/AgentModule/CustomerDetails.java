package com.dxc.ams2.entity;

public class CustomerDetails {
	String cno;
	public CustomerDetails()
	{
		
	}
	public CustomerDetails(String cno, String fname, String lname, String login, String pwd, String email, String addr,
			long phnum, String agno) {
		super();
		this.cno = cno;
		this.fname = fname;
		this.lname = lname;
		this.login = login;
		this.pwd = pwd;
		this.email = email;
		this.addr = addr;
		this.phnum = phnum;
		this.agno = agno;
	}
	String fname;
	String lname;
	String login;
	String pwd;
	String email;
	String addr;
	long phnum;
	String agno;
	public String getCno() {
		return cno;
	}
	public void setCno(String cno) {
		this.cno = cno;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public long getPhnum() {
		return phnum;
	}
	public void setPhnum(long phnum) {
		this.phnum = phnum;
	}
	public String getAgno() {
		return agno;
	}
	public void setAgno(String agno) {
		this.agno = agno;
	}
	@Override
	public String toString() {
		return "CustomerDetails [cno=" + cno + ", fname=" + fname + ", lname=" + lname + ", login=" + login + ", pwd="
				+ pwd + ", email=" + email + ", addr=" + addr + ", phnum=" + phnum + ", agno=" + agno + "]";
	}
	
	

}
