package com.dxc.am2.agent.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.dxc.ams2.agent.crud.AgentCurd;
import com.dxc.ams2.dbconnection.DBConnection;
import com.dxc.ams2.entity.Appt;
import com.dxc.ams2.entity.CustomerDetails;
import com.dxc.ams2.entity.PolicyDetails;

public class AgentImpl implements AgentCurd {
        @Override
	public void addCustomerDetails(CustomerDetails cd) {
		// TODO Auto-generated method stub
		
			DBConnection db=new DBConnection();

			Connection c=db.getConnected();

			if(c==null)
			{
				System.out.println("connection failed");
			}
			else if(c!=null)
			{
				System.out.println("Succesfully Connected to Database");
			}

			try {
				PreparedStatement ps=c.prepareStatement("insert into customerdetails values(?,?,?,?,?,?,?,?,?)");
			
				

				ps.setString(1, cd.getCno());
	            ps.setString(2, cd.getFname());
	            ps.setString(3, cd.getLname());
	            ps.setString(4, cd.getLogin());
	            ps.setString(5, cd.getPwd());
	            ps.setString(6, cd.getEmail());
	            ps.setString(7, cd.getAddr());
	            ps.setLong(8, cd.getPhnum());
	            ps.setString(9, cd.getAgno());


	            


				ps.executeUpdate();


			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		}
@Override
	public void addApp(Appt a) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();
		Connection c=db.getConnected();
		if(c==null)
		{
			System.out.println("Connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Sucessfully connected");
		}
		try
		{
			PreparedStatement pst=c.prepareStatement("insert into app values(?,?,?,?,?)");
			pst.setString(1, a.getApid());
            pst.setString(2, a.getAgno());
            pst.setString(3, a.getApdate());
            pst.setString(4, a.getTime());
            pst.setString(5, a.getCsname());
            pst.executeUpdate();
            
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		
	}
	@Override
	public void NewAppointment(Appt a) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			PreparedStatement ps=c.prepareStatement("insert into app values(?,?,?,?,?)");
			ps.setString(1,"AP1242");
			ps.setString(2,"AG1242");
			ps.setString(3,"Mon oct 02 00:00:00 GMT+05:30 2005");
			ps.setString(4,"9:00-10:00");
			ps.setString(5,"koti");
			
			ps.executeUpdate();
		
		
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	@Override
	public void deleteAppoinment(Appt a) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			PreparedStatement ps=c.prepareStatement("delete from app where apdate='Fri Jun 30 00:00:00 IST 2006' ");
			ps.executeUpdate();
		
		
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	@Override
	public void viewPolicyDetails(PolicyDetails pd) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			Statement st=c.createStatement();
			ResultSet res=st.executeQuery("select * from policy1");
			while(res.next())
			{
				System.out.println(res.getString("pno")+"   "+res.getString("csno")+"   "+res.getString("pdate")+"   "+res.getInt("year")+"   "+res.getLong("pamt")+"   "+res.getString("mode")+"   "+res.getInt("premium"));
				
			}
		
	      }catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	@Override
	public void viewAppInfo(Appt a) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			Statement st=c.createStatement();
			ResultSet res=st.executeQuery("select * from app");
			while(res.next())
			{
				System.out.println(res.getString("apid")+"   "+res.getString("agno")+"   "+res.getString("apdate")+"   "+res.getString("time")+"   "+res.getString("csname"));
				
			}
		
		
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	@Override
	public void viewCustDetails(CustomerDetails cd) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			Statement st=c.createStatement();
			ResultSet res=st.executeQuery("select * from customerdetails");
			while(res.next())
			{
				System.out.println(res.getString("cno")+"   "+res.getString("fname")+"   "+res.getString("lname")+"   "+res.getString("login")+"   "+res.getString("pwd")+"   "+res.getString("email")+"   "+res.getString("addr")+" "+res.getLong("phnum")+" "+res.getString("agno"));
				
			}
		
	      }catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
		
		
	}

		
			
		
	

		
	
		
	



	
	

	


