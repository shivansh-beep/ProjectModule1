package com.dxc.ams2.entity;

public class Appt {
	String apid;
	public Appt()
	{
		
	}
	public Appt(String apid, String agno, String apdate, String time, String csname) {
		super();
		this.apid = apid;
		this.agno = agno;
		this.apdate = apdate;
		this.time = time;
		this.csname = csname;
	}
	String agno;
	String apdate;
	String time;
	String csname;
	public String getApid() {
		return apid;
	}
	public void setApid(String apid) {
		this.apid = apid;
	}
	public String getAgno() {
		return agno;
	}
	public void setAgno(String agno) {
		this.agno = agno;
	}
	public String getApdate() {
		return apdate;
	}
	public void setApdate(String apdate) {
		this.apdate = apdate;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getCsname() {
		return csname;
	}
	public void setCsname(String csname) {
		this.csname = csname;
	}
	@Override
	public String toString() {
		return "Appt [apid=" + apid + ", agno=" + agno + ", apdate=" + apdate + ", time=" + time + ", csname=" + csname
				+ "]";
	}
	

}
