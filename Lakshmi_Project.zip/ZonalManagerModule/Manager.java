package com.dxc.ams2.entity;
public class Manager
{
	String mgno;
	public Manager()
	{

	}
	public Manager(String mgno, String fname, String lname, String login, String pwd, String email, String addr,
			String bno, int phnum) {
		super();
		this.mgno = mgno;
		this.fname = fname;
		this.lname = lname;
		this.login = login;
		this.pwd = pwd;
		this.email = email;
		this.addr = addr;
		this.bno = bno;
		this.phnum = phnum;
	}
	String fname;
	String lname;
	String login;
	String pwd;
	String email;
	String addr;
	String bno;
	int phnum;
	public String getMgno() {
		return mgno;
	}
	public void setMgno(String mgno) {
		this.mgno = mgno;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getBno() {
		return bno;
	}
	public void setBno(String bno) {
		this.bno = bno;
	}
	public int getPhnum() {
		return phnum;
	}
	public void setPhnum(int phnum) {
		this.phnum = phnum;
	}
	@Override
	public String toString() {
		return "Manager [mgno=" + mgno + ", fname=" + fname + ", lname=" + lname + ", login=" + login + ", pwd=" + pwd
				+ ", email=" + email + ", addr=" + addr + ", bno=" + bno + ", phnum=" + phnum + "]";
	}
	
}
	            
		