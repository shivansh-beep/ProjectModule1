package com.dxc.am2.zonal.impl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.dxc.ams2.dbconnection.DBConnection;
import com.dxc.ams2.entity.AgentList;
import com.dxc.ams2.entity.Branch;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.PolicyDetails;
import com.dxc.ams2.entity.Zonal;
import com.dxc.ams2.zonal.crud.ZonalManagerCrud;

public class ZonalManagerImpl implements ZonalManagerCrud {
	
	public void addManager(Manager m)  
	{
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			PreparedStatement ps=c.prepareStatement("insert into manager1 values(?,?,?,?,?,?,?,?,?)");
		
			

			ps.setString(1, m.getMgno());
            ps.setString(2, m.getFname());
            ps.setString(3, m.getLname());
            ps.setString(4, m.getLogin());
            ps.setString(5, m.getPwd());
            ps.setString(6, m.getEmail());
            ps.setString(7, m.getAddr());
            ps.setString(8, m.getBno());
            ps.setInt(9, m.getPhnum());


            


			ps.executeUpdate();


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	
	@Override
	public void addAgent(AgentList al) {
		
		DBConnection db=new DBConnection();
		Connection c=db.getConnected();
		if(c==null)
		{
			System.out.println("Connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Sucessfully connected");
		}
		try
		{
			PreparedStatement pst=c.prepareStatement("insert into agentlists values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			pst.setString(1, al.getAgno());
            pst.setString(2, al.getFname());
            pst.setString(3, al.getLname());
            pst.setString(4, al.getLogin());
            pst.setString(5, al.getAddr());
            pst.setString(6, al.getPtype());
            pst.setString(7, al.getBrno());
            pst.setString(8, al.getEmail());
            pst.setString(9, al.getAddr());
            pst.setLong(10, al.getPhnum());
            pst.setInt(11, al.getTarget());
            pst.setString(12, al.getTdate());
            pst.setString(13, al.getTsdate());
            pst.setInt(14, al.getPsold());
            pst.executeUpdate();
            
            
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		
	}

	@Override
	public void addZonal(Zonal z) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();
		Connection c=db.getConnected();
		if(c==null)
		{
			System.out.println("Connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Sucessfully connected");
		}
		try
		{
			PreparedStatement pst=c.prepareStatement("insert into zonallists1 values(?,?,?,?,?)");
			pst.setString(1, z.getZmnno());
            pst.setString(2, z.getFname());
            pst.setString(3, z.getLname());
            pst.setString(4, z.getLogin());
            pst.setString(5, z.getPwd());
            pst.executeUpdate();
            
		
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

	@Override
	public void addBranch(Branch b) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();
		Connection c=db.getConnected();
		if(c==null)
		{
			System.out.println("Connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Sucessfully connected");
		}
		try
		{
			
			PreparedStatement pst=c.prepareStatement("insert into branch values(?,?,?,?)");
			

			pst.setString(1, b.getBrno());
            pst.setString(2, b.getBrname());
            pst.setString(3, b.getBraddr());
            pst.setString(4, b.getZmgno());
            pst.executeUpdate();
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

	@Override
	public void addPolicyDetails(PolicyDetails pd) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();
		Connection c=db.getConnected();
		if(c==null)
		{
			System.out.println("Connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Sucessfully connected");
		}
		try
		{
			PreparedStatement pst=c.prepareStatement("insert into policy1 values(?,?,?,?,?,?,?)");
			
			pst.setString(1, pd.getPno());
            pst.setString(2, pd.getCsno());
            pst.setString(3, pd.getPdate());
            pst.setInt(4, pd.getYear());
            pst.setLong(5, pd.getPamt());
            pst.setString(6, pd.getMode());
            pst.setInt(7, pd.getPremium());
            pst.executeUpdate();
            
		
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	}

	@Override
	public void addNewBranch(Branch b) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();
		Connection c=db.getConnected();
		if(c==null)
		{
			System.out.println("Connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Sucessfully connected");
		}
		try
		{
			
			PreparedStatement pst=c.prepareStatement("insert into branch values(?,?,?,?)");
			

			pst.setString(1,"BR100");
            pst.setString(2, "lakshmi");
            pst.setString(3, "palem");
            pst.setString(4, "ZM1242");
            pst.executeUpdate();
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

	@Override
	public void addNewManager(Manager m) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			PreparedStatement ps=c.prepareStatement("insert into manager1 values(?,?,?,?,?,?,?,?,?)");
		
			

			ps.setString(1,"MG1242");
            ps.setString(2,"lakshmi");
            ps.setString(3,"reddy");
            ps.setString(4,"koti");
            ps.setString(5,"koti1242");
            ps.setString(6,"koti@gmail.com");
            ps.setString(7,"palem");
            ps.setString(8,"BR42");
            ps.setInt(9, 773183641);


            


			ps.executeUpdate();


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	@Override
	public void replaceManager(Manager m) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			PreparedStatement ps=c.prepareStatement("update manager1 set fname=replace(fname,'madhu','Raj') where fname='madhu'");
		
			
            

            


			ps.executeUpdate();


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		
	}

	
		
	}
		
	




	


	


