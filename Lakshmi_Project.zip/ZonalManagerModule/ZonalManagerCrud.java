package com.dxc.ams2.zonal.crud;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.AgentList;
import com.dxc.ams2.entity.Zonal;
import com.dxc.ams2.entity.Branch;
import com.dxc.ams2.entity.PolicyDetails;


public interface ZonalManagerCrud 
{
    public void addManager(Manager m);
     public void addAgent(AgentList al);
     public void addZonal(Zonal z);
     public void addBranch(Branch b);
     public void addPolicyDetails(PolicyDetails pd);
     public void addNewBranch(Branch b);
     public void addNewManager(Manager m);
     public void replaceManager(Manager m);
     
}

