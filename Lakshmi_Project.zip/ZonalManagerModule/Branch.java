package com.dxc.ams2.entity;

public class Branch {
	String brno;
	public Branch(String brno, String brname, String braddr, String zmgno) {
		super();
		this.brno = brno;
		this.brname = brname;
		this.braddr = braddr;
		this.zmgno = zmgno;
	}
	String brname;
	String braddr;
	String zmgno;
	public String getBrno() {
		return brno;
	}
	public void setBrno(String brno) {
		this.brno = brno;
	}
	public String getBrname() {
		return brname;
	}
	public void setBrname(String brname) {
		this.brname = brname;
	}
	public String getBraddr() {
		return braddr;
	}
	public void setBraddr(String braddr) {
		this.braddr = braddr;
	}
	public String getZmgno() {
		return zmgno;
	}
	public void setZmgno(String zmgno) {
		this.zmgno = zmgno;
	}
	@Override
	public String toString() {
		return "Branch [brno=" + brno + ", brname=" + brname + ", braddr=" + braddr + ", zmgno=" + zmgno + "]";
	}
	

}
