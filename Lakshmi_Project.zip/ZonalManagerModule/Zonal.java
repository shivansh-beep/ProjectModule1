package com.dxc.ams2.entity;

public class Zonal {
	String zmnno;
	public String getZmnno() {
		return zmnno;
	}

	public void setZmnno(String zmnno) {
		this.zmnno = zmnno;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	String fname;
	String lname;
	String login;
	String pwd;
	
	public Zonal(String zmnno, String fname, String lname, String login, String pwd) {
		super();
		this.zmnno = zmnno;
		this.fname = fname;
		this.lname = lname;
		this.login = login;
		this.pwd = pwd;
	}

	@Override
	public String toString() {
		return "Zonal [zmnno=" + zmnno + ", fname=" + fname + ", lname=" + lname + ", login=" + login + ", pwd=" + pwd
				+ "]";
	}
	

}


	


