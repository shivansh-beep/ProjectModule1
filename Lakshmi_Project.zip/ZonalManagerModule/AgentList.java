package com.dxc.ams2.entity;

public class AgentList {
	String agno;
        public AgentList()
	{
 	}
	public AgentList(String agno, String fname, String lname, String login, String pwd, String ptype, String brno,
			String email, String addr, long phnum, int target, String tdate, String tsdate, int psold) {
		super();
		this.agno = agno;
		this.fname = fname;
		this.lname = lname;
		this.login = login;
		this.pwd = pwd;
		this.ptype = ptype;
		this.brno = brno;
		this.email = email;
		this.addr = addr;
		this.phnum = phnum;
		this.target = target;
		this.tdate = tdate;
		this.tsdate = tsdate;
		this.psold = psold;
	}
	String fname;
	String lname;
	String login;
	String pwd;
	String ptype;
	String brno;
	String email;
	String addr;
	long phnum;
	int target;
	String tdate;
	String tsdate;
	int psold;
	public String getAgno() {
		return agno;
	}
	public void setAgno(String agno) {
		this.agno = agno;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPtype() {
		return ptype;
	}
	public void setPtype(String ptype) {
		this.ptype = ptype;
	}
	public String getBrno() {
		return brno;
	}
	public void setBrno(String brno) {
		this.brno = brno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public long getPhnum() {
		return phnum;
	}
	public void setPhnum(long phnum) {
		this.phnum = phnum;
	}
	public int getTarget() {
		return target;
	}
	public void setTarget(int target) {
		this.target = target;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	public String getTsdate() {
		return tsdate;
	}
	public void setTsdate(String tsdate) {
		this.tsdate = tsdate;
	}
	public int getPsold() {
		return psold;
	}
	public void setPsold(int psold) {
		this.psold = psold;
	}
	@Override
	public String toString() {
		return "AgentList [agno=" + agno + ", fname=" + fname + ", lname=" + lname + ", login=" + login + ", pwd=" + pwd
				+ ", ptype=" + ptype + ", brno=" + brno + ", email=" + email + ", addr=" + addr + ", phnum=" + phnum
				+ ", target=" + target + ", tdate=" + tdate + ", tsdate=" + tsdate + ", psold=" + psold + "]";
	}
	
	
	

}
