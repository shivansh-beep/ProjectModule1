import com.dxc.am2.zonal.impl.ZonalManagerImpl;
import com.dxc.am2.agent.impl.AgentImpl;
import com.dxc.am2.customer.impl.CustomerImpl;
import com.dxc.am2.manager.impl.*;
import com.dxc.ams2.entity.AgentList;
import com.dxc.ams2.entity.Appt;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.Zonal;
import com.dxc.ams2.entity.Branch;
import com.dxc.ams2.entity.CustomerDetails;
import com.dxc.ams2.entity.PolicyDetails;



public class AmsApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager m=new Manager("MG1242","lakshmi","Reddy","koti","koti1242","koti@gmail.com","palem","BR42",773183641);
		AgentList al=new AgentList("AG1242","koti","reddy","koti","koti1242","SLK","BR1242","koti@gmail.com","palem",7731836412l,7,"Sun Oct 07 00:00:00 GMT+04:15 2006","Thu feb 01 15:08:37 GMT+05:30 2006",0);
        Zonal z=new Zonal("ZM003","venkat","prasad","reddy","vpr");
		Branch b=new Branch("BR100","koti","palem","ZM1242");
        PolicyDetails pd=new PolicyDetails("SJK102","CS011","06-16-2006",9,230000l,"Quarterly",2100);
		CustomerDetails cd=new CustomerDetails("CS021"," rock ","stephen","AG002","pass","rock@gmail.com","jkdsafj",465454l,"AG0028");
	    Appt a=new Appt("AP0019","AG003","Mon Jul 03 00:00:00 IST 2006","3:00-4:00","Mr Vijay");
		ZonalManagerImpl zobj=new ZonalManagerImpl();
		zobj.addManager(m);
		zobj.addAgent(al);
		zobj.addZonal(z);
		zobj.addBranch(b);
		zobj.addPolicyDetails(pd);
		zobj.addNewManager(m);
		zobj.replaceManager(m);
		zobj.addNewBranch(b);
		
		ManagerImpl mobj=new ManagerImpl();
		mobj.viewManager(m);
		mobj.viewAgent(al);
		mobj.viewPolicyDetails(pd);
		mobj.addNewAgent(al);
		mobj.setTarget(al);
		
		AgentImpl ai=new AgentImpl();
		ai.addApp(a);
		ai.NewAppointment(a);
		ai.deleteAppoinment(a);
	    ai.viewPolicyDetails(pd);
		ai.viewAppInfo(a);
		ai.viewCustDetails(cd);
		     
		CustomerImpl cobj=new CustomerImpl();
		cobj.changePassword(cd);
		cobj.viewCustomer(cd);
		cobj.viewPolicyDetails(pd);
		   
		   
		   System.out.println("LogOut");
		


	}





			}

		

	


