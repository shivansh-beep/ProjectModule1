package com.dxc.ams2.manager.crud;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.AgentList;
import com.dxc.ams2.entity.PolicyDetails;
import com.dxc.ams2.entity.CustomerDetails;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.entity.PolicyDetails;
import com.dxc.ams2.entity.AgentList;

public interface ManagerCrud {
	public void viewManager(Manager m);
	 public void viewAgent(AgentList al);
	public void viewPolicyDetails(PolicyDetails pd);
	public void addNewAgent(AgentList al);
	public void setTarget(AgentList al);
	

}
