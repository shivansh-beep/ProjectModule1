package com.dxc.am2.manager.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.dxc.ams2.dbconnection.DBConnection;
import com.dxc.ams2.entity.CustomerDetails;
import com.dxc.ams2.entity.AgentList;
import com.dxc.ams2.entity.PolicyDetails;
import com.dxc.ams2.entity.AgentList;
import com.dxc.ams2.entity.Manager;
import com.dxc.ams2.manager.crud.ManagerCrud;

public class ManagerImpl implements ManagerCrud {

	

	@Override
	public void viewManager(Manager m) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			Statement st=c.createStatement();
			ResultSet res=st.executeQuery("select *  from manager1");
			while(res.next())
			{
				System.out.println(res.getString("mgno")+"    "+res.getString("fname")+"   "+res.getString("lname")+"   "+res.getString("login")+"  "+res.getString("pwd")+" "+res.getString("email")+"  "+res.getString("addr")+"  "+res.getString("bno")+" "+res.getInt("phnum"));
				
			}
		
	      }catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

	@Override
	public void viewAgent(AgentList al) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			Statement st=c.createStatement();
			ResultSet res=st.executeQuery("select *  from agentlists");
			while(res.next())
			{
				System.out.println(res.getString("agno")+"    "+res.getString("fname")+"   "+res.getString("lname")+"   "+res.getString("login")+"  "+res.getString("pwd")+" "+res.getString("brno")+"  "+res.getString("email")+"  "+res.getString("addr")+" "+res.getLong("phnum")+" "+res.getInt("target")+" "+res.getString("tdate")+" "+res.getString("tsdate")+" "+res.getInt("psold"));
				
			}
		
	      }catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
		@Override
	public void addNewAgent(AgentList al) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();
		Connection c=db.getConnected();
		if(c==null)
		{
			System.out.println("Connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Sucessfully connected");
		}
		try
		{
			PreparedStatement pst=c.prepareStatement("insert into agentlists values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			pst.setString(1, "AG1242");
            pst.setString(2,"koti");
            pst.setString(3,"reddy");
            pst.setString(4,"koti");
            pst.setString(5,"palem");
            pst.setString(6, "SLK");
            pst.setString(7, "BR1242");
            pst.setString(8, "koti@gmail.com");
            pst.setString(9, "palem");
            pst.setLong(10, 77318364);
            pst.setInt(11,412);
            pst.setString(12, "Tue oct 03 00:00:00 GMT+04:15 2006");
            pst.setString(13,"Mon feb 26 19:12:43 GMT+05:30 2006");
            pst.setInt(14, 0);
           
            pst.executeUpdate();
            
            
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		
	}
	
	

	@Override
	public void viewPolicyDetails(PolicyDetails pd) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			Statement st=c.createStatement();
			ResultSet res=st.executeQuery("select * from policy1");
			while(res.next())
			{
				System.out.println(res.getString("pno")+"   "+res.getString("csno")+"   "+res.getString("pdate")+"   "+res.getInt("year")+"   "+res.getLong("pamt")+"   "+res.getString("mode")+"   "+res.getInt("premium"));
				
			}
		
	      }catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	public void setTarget(AgentList al) {
		// TODO Auto-generated method stub
		DBConnection db=new DBConnection();

		Connection c=db.getConnected();

		if(c==null)
		{
			System.out.println("connection failed");
		}
		else if(c!=null)
		{
			System.out.println("Succesfully Connected to Database");
		}

		try {
			PreparedStatement ps=c.prepareStatement("update agentlists set target=500 where lname='Rao' ");
			ps.executeUpdate();
		
		
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
		
		
		
	}



	
	
		
	
		
	


